#include <GL/glut.h>
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char username[50];
    char parola[50];
} Utilizator;

Utilizator utilizatori[50];
int numarUtilizatori = 0;
char utilizatorCurent[50];

void citireUtilizatori() {
    FILE *file = fopen("date1.txt", "r");

    while (fscanf(file, "%s %s", utilizatori[numarUtilizatori].username, utilizatori[numarUtilizatori].parola) != EOF) {
        numarUtilizatori++;
    }

    fclose(file);
}

void scriereUtilizatori() {
    FILE *file = fopen("date1.txt", "w");

    for (int i = 0; i < numarUtilizatori; i++) {
        fprintf(file, "%s %s\n", utilizatori[i].username, utilizatori[i].parola);
    }

    fclose(file);
}

int verificare(const char *username, const char *parola) {//verificare autentificare
    for (int i = 0; i < numarUtilizatori; i++) {
        if (strcmp(utilizatori[i].username, username) == 0 && strcmp(utilizatori[i].parola, parola) == 0) {
            strcpy(utilizatorCurent, username);
            return 1;
        }
    }
    return 0;
}

void actualizare(const char *username, const char *parolaNoua) {
    for (int i = 0; i < numarUtilizatori; i++) {
        if (strcmp(utilizatori[i].username, username) == 0) {
            strcpy(utilizatori[i].parola, parolaNoua);
            return;
        }
    }
}

void parolaUitata(const char *username) {
    char parolaNoua[50];

    printf("Introduceti parola noua: ");
    fflush(stdout);
    scanf("%s", parolaNoua);

    actualizare(username, parolaNoua);

    printf("Parola a fost resetata cu succes!\n");
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    char text[100];
    sprintf(text, "Bun venit %s!", utilizatorCurent);

    //lungime chenar
    const float lungime = 0.6f;
    const float inaltime = 0.1f;

    // Coordonate chenar
    const float stanga = -0.95f;
    const float dreapta = stanga + lungime;
    const float sus = 0.85f;
    const float jos = sus - inaltime;

    glColor3f(1.0f, 1.0f, 1.0f);
    glBegin(GL_QUADS);
        glVertex2f(stanga, jos);
        glVertex2f(dreapta, jos);
        glVertex2f(dreapta, sus);
        glVertex2f(stanga, sus);
    glEnd();

    glColor3f(0.0f, 0.0f, 0.0f);

    // Coordonatele text
    float Xtext = stanga + 0.02f;
    float Ytext = jos + 0.02f;

    glRasterPos2f(Xtext, Ytext);
    for (const char *c = text; *c != '\0'; c++) {
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *c);
    }


    //Dimensiuni chenare
    const float lungimeAcasa = 0.2f;
    const float inaltimeAcasa = 0.1f;

    const float lungimeMisiune = 0.4f;
    const float inaltimeMisiune = 0.1f;

    const float lungimeClient = 0.2f;
    const float inaltimeClient = 0.1f;

    const float lungimeContact = 0.2f;
    const float inaltimeContact = 0.1f;

    const float lungimeIng = 0.6f;
    const float inaltimeIng = 0.1f;


    // Coordonatele chenarului
    const float stangaAcasa = stanga;
    const float dreaptaAcasa = stangaAcasa + lungimeAcasa;
    const float josAcasa = jos - 0.15f;
    const float susAcasa = josAcasa + inaltimeAcasa;

    const float stangaMisiune = dreaptaAcasa + 0.1f;
    const float dreaptaMisiune = stangaMisiune + lungimeMisiune;
    const float josMisiune = josAcasa;
    const float susMisiune = josMisiune + inaltimeMisiune;

    const float stangaClient = dreaptaMisiune + 0.1f;
    const float dreaptaClient = stangaClient + lungimeClient;
    const float josClient = josMisiune;
    const float susClient = josClient + inaltimeClient;

    const float stangaContact = dreaptaClient + 0.1f;
    const float dreaptaContact = stangaContact + lungimeContact;
    const float josContact = josClient;
    const float susContact = josContact + inaltimeContact;

    const float stangaIng = dreaptaContact + 0.1f;
    const float dreaptaIng = stangaIng + lungimeIng;
    const float josIng = josContact;
    const float susIng = josIng + inaltimeIng;


    glColor3f(0.6f, 0.0f, 1.0f);
    glBegin(GL_QUADS);
        glVertex2f(stangaAcasa, josAcasa);
        glVertex2f(dreaptaAcasa, josAcasa);
        glVertex2f(dreaptaAcasa, susAcasa);
        glVertex2f(stangaAcasa, susAcasa);
    glEnd();

    glColor3f(1.0f, 1.0f, 1.0f);

    float Xacasa = stangaAcasa + 0.02f;
    float Yacasa = josAcasa + 0.02f;

    const char *textAcasa = "||| Acasa";
    glRasterPos2f(Xacasa, Yacasa);
    for (const char *c = textAcasa; *c != '\0'; c++) {
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *c);
    }



    glColor3f(0.6f, 0.0f, 1.0f);
    glBegin(GL_QUADS);
        glVertex2f(stangaMisiune, josMisiune);
        glVertex2f(dreaptaMisiune, josMisiune);
        glVertex2f(dreaptaMisiune, susMisiune);
        glVertex2f(stangaMisiune, susMisiune);
    glEnd();

    glColor3f(1.0f, 1.0f, 1.0f);

    float Xmisiune = stangaMisiune + 0.02f;
    float Ymisiune = josMisiune + 0.02f;

    const char *mission_text = "||| Misiune/Viziune";
    glRasterPos2f(Xmisiune, Ymisiune);
    for (const char *c = mission_text; *c != '\0'; c++) {
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *c);
    }



    glColor3f(0.6f, 0.0f, 1.0f);
    glBegin(GL_QUADS);
        glVertex2f(stangaClient, josClient);
        glVertex2f(dreaptaClient, josClient);
        glVertex2f(dreaptaClient, susClient);
        glVertex2f(stangaClient, susClient);
    glEnd();

    glColor3f(1.0f, 1.0f, 1.0f);

    float Xclient = stangaClient + 0.02f;
    float Yclient = josClient + 0.02f;

    const char *clients_text = "||| Clienti";
    glRasterPos2f(Xclient, Yclient);
    for (const char *c = clients_text; *c != '\0'; c++) {
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *c);
    }




    glColor3f(0.6f, 0.0f, 1.0f);
    glBegin(GL_QUADS);
        glVertex2f(stangaContact, josContact);
        glVertex2f(dreaptaContact, josContact);
        glVertex2f(dreaptaContact, susContact);
        glVertex2f(stangaContact, susContact);
    glEnd();

    glColor3f(1.0f, 1.0f, 1.0f);

    float Xcontact = stangaContact + 0.02f;
    float Ycontact = josContact + 0.02f;

    const char *contact_text = "||| Contact";
    glRasterPos2f(Xcontact, Ycontact);
    for (const char *c = contact_text; *c != '\0'; c++) {
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *c);
    }



    glColor3f(0.6f, 0.0f, 1.0f);
    glBegin(GL_QUADS);
        glVertex2f(stangaIng, josIng);
        glVertex2f(dreaptaIng, josIng);
        glVertex2f(dreaptaIng, susIng);
        glVertex2f(stangaIng, susIng);
    glEnd();

    glColor3f(1.0f, 1.0f, 1.0f); // alb

    float Xing = stangaIng + 0.02f;
    float Ying = josIng + 0.02f;

    const char *registration_text = "||| Inregistrare/Autentificare";
    glRasterPos2f(Xing, Ying);
    for (const char *c = registration_text; *c != '\0'; c++) {
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *c);
    }


    const float lungimeBuna = 1.6f;
    const float inaltimeBuna = 0.3f;

    const float stangaBuna = -lungimeBuna / 2.0f;
    const float dreaptaBuna = stangaBuna + lungimeBuna;
    const float josBuna = 0.0f;
    const float susBuna = josBuna + inaltimeBuna;

    glColor3f(0.6f, 0.0f, 1.0f);
    glBegin(GL_QUADS);
        glVertex2f(stangaBuna, josBuna);
        glVertex2f(dreaptaBuna, josBuna);
        glVertex2f(dreaptaBuna, susBuna);
        glVertex2f(stangaBuna, susBuna);
    glEnd();

    glColor3f(1.0f, 1.0f, 1.0f);

    float Xbuna = stangaBuna + 0.1f;
    float Ybuna = josBuna + inaltimeBuna / 2.0f;

    const char *welcome_text = "Bun venit pe site-ul nostru!";
    glRasterPos2f(Xbuna, Ybuna);
    for (const char *c = welcome_text; *c != '\0'; c++) {
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *c);
    }

    glutSwapBuffers();
}


void grafica(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(900, 700);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("Site");

    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-1.0, 1.0, -1.0, 1.0);

    glutDisplayFunc(display);
    glutMainLoop();
}

void autentificare(int argc, char** argv) {
    char username[50], parola[50];
    int optiune;

    printf("Introduceti username: ");
    fflush(stdout);
    scanf("%s", username);

    printf("Introduceti parola: ");
    fflush(stdout);
    scanf("%s", parola);

    if (verificare(username, parola)) {
        printf("Autentificare reusita!\n");

        grafica(argc, argv);

    } else {
        printf("Parola gresita!\n");
        printf("1. Introduceti din nou\n");
        printf("2. Parola uitata\n");

        printf("Alegeti optiunea: ");
        fflush(stdout);
        scanf("%d", &optiune);

        if (optiune == 1) {
            autentificare(argc, argv);
        } else if (optiune == 2) {
            parolaUitata(username);
        } else {
            printf("Optiune invalida!\n");
        }
    }
}

void inregistrare() {
    char username[50], parola[50];

    printf("Introduceti username nou: ");
    fflush(stdout);
    scanf("%s", username);

    printf("Introduceti parola noua: ");
    fflush(stdout);
    scanf("%s", parola);

    strcpy(utilizatori[numarUtilizatori].username, username);
    strcpy(utilizatori[numarUtilizatori].parola, parola);
    numarUtilizatori++;

    printf("Inregistrare reusita!\n");
}

int main(int argc, char** argv) {
    int optiune;

    citireUtilizatori();

    printf("1. Autentificare\n");
    printf("2. Inregistrare\n");

    printf("Alegeti optiunea: ");
    fflush(stdout);
    scanf("%d", &optiune);

    switch (optiune) {
        case 1:
            autentificare(argc, argv);
            break;
        case 2:
            inregistrare();
            break;
        default:
            printf("Optiune invalida!\n");
            fflush(stdout);
            break;
    }

    scriereUtilizatori();

    return 0;
}
